DxBlazorInternal.define("cjs-chunk-8bdf5a55.js",(function(n,e,a){a.Key={Enter:13,Home:36,End:35,Up:38,Down:40,PageUp:33,PageDown:34,Esc:27,Tab:9,Backspace:8}}),[]);
