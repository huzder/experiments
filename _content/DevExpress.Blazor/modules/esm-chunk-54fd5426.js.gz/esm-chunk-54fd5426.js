const a={Enter:13,Home:36,End:35,Up:38,Down:40,PageUp:33,PageDown:34,Esc:27,Tab:9,Backspace:8};export{a as K};
